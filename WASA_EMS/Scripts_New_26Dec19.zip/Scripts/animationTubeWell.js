﻿

var loopStartTime = 30000;
var video = document.querySelector('#tubvelVideo');
var video_loop = document.querySelector('#tubvelVideo-loop');


// First angle value of equal 5 parts reading
var points_gap = 45;
    
// Starting angle where value should be zero
var starting_val = 45;

// Ending angle where maximum value will be 5
var ending_val = 315;

// Current value for meter reading
var current_reading = 0;

// Current reading from server (1 to 5)
var server_input = 2.34;


startPump = () => {
    video.play();
    setTimeout(function(){
        video.style.display = 'none';
        video.currentTime = 0;

        video_loop.style.display = 'block';
        video_loop.play();
        video_loop.loop = true;

    }, loopStartTime);
};

stopPump = () => {

    video_loop.style.display = 'none';
    video.style.display = 'block';

    video_loop.pause();
    video_loop.currentTime = 0;

    video.pause();
    video.currentTime = 0;
}

changeFlowMeterValue = (value) => {
    $('.flow-meter .flow-meter-inner .meter-nib')
        .css('transform', 'rotate(' + value + 'deg)');
}

changePressureTransmitterValue = (value) => {
    $('.pressure-transmitter .pressure-transmitter-inner .meter-nib')
        .css('transform', 'rotate(' + value + 'deg)');
}

$(document).ready(function(){


    // Flow-meter controls
    // ------------------------------------------------------------------
    
    // First flow meter reading
    if( server_input <= 1 ) {
        current_reading = server_input * points_gap + points_gap;
        console.log(current_reading);
        changeFlowMeterValue(current_reading);
    } 
    
    // Second flow meter reading
    else if( server_input <= 2 ){
        current_reading = server_input * points_gap + points_gap;
        console.log(current_reading);
        changeFlowMeterValue(current_reading);
    }

    // Third flow meter reading
    else if( server_input <= 3 ){
        current_reading = server_input * points_gap + points_gap;
        console.log(current_reading);
        changeFlowMeterValue(current_reading);
    }

    // Forth flow meter reading
    else if( server_input <= 4 ){
        current_reading = server_input * points_gap + points_gap;
        console.log(current_reading);
        changeFlowMeterValue(current_reading);
    }

    // Fifth flow meter reading
    else if( server_input <= 5 ){
        current_reading = server_input * points_gap + points_gap;
        console.log(current_reading);
        changeFlowMeterValue(current_reading);
    }


    $('#btn-pump-start').click(function(){
        startPump();
    });

    $('#btn-pump-stop').click(function(){
        stopPump();
    });

    $('input[name="flow_meter_range"]').on( 'input', function(){
        changeFlowMeterValue($(this).val());
    });

    $('input[name="pressure_transmitter_range"]').on( 'input', function(){
        changePressureTransmitterValue($(this).val());
    });

    $('input[name="flow_meter_check"]').on('change', function(){
        if( $(this).is(":checked") ){
            $('.flow-meter-inner').addClass('show');
        }else{
            $('.flow-meter-inner').removeClass('show');
        }
    });

    $('input[name="pressure_transmitter_check"]').on('change', function(){
        if( $(this).is(":checked") ){
            $('.pressure-transmitter-inner').addClass('show');
        }else{
            $('.pressure-transmitter-inner').removeClass('show');
        }
    });

    
    

});
